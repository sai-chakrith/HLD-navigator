# HLD Navigator submission draft - version 1.2

Student: Sai Chakrith Sulluru
University: Amrita Viswa Vidyapeetham
Faculty guide: Dr. D. Palmani
Register/team ID: NOT SUPPLIED. Replace ID_PENDING before submission.

Read Documentation/study-notes/COMPLETION_REPORT.md first.
Source lives in Code/HLD-navigator. From that directory run:

    uv sync --frozen --extra dev
    uv run python tools/demo.py

Open http://127.0.0.1:8511. Set API port 8011, workspace demo and the private token
printed by the launcher. A new isolated demo database is created; no credentials
or live databases are shipped. Inference weights/runtime are omitted intentionally;
optional model provisioning commands and pinned hashes are included.

499 regressions pass locally. The default uses cited lexical source excerpts.
Optional model synthesis still has semantic mistakes and requires human review.
Evidence is synthetic/public developer validation, not independent OEM acceptance.
The five-minute video is a captioned sequence of actual UI captures, not a
continuous screen/voice recording. Practice and personalize the presentation/demo.

Synopsis and declarations are unsigned. Obtain faculty approval and personally
verify/sign student declarations. No identity, signatures or external acceptance
were invented. Source/AI assistance is disclosed. No external applications sent.

MANIFEST.json records SHA-256 for every packaged file except itself.
